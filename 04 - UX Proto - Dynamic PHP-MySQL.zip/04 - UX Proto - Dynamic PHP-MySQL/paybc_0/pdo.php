<?php

if(isset($_POST['ref_no']) && isset($_POST['transaction_no'])){ //if the post variables are set (e.g., we're coming from the Search form)
     // Escapes special characters
    $ref_no = mysql_real_escape_string(htmlspecialchars($_POST['ref_no']));
    $transaction_no = mysql_real_escape_string(htmlspecialchars($_POST['transaction_no']));
    
    // create database connection variables
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "paybc_as_is";
    
    //create SQL query
    $sql = "SELECT
            ID,
            ref_no,
            transaction_source,
            transaction_date,
            consolidated_invoice_no,
            transaction_no,
            customer_no,
            class,
            type,
            bill_to,
            description,
            quantity,
            uom,
            amount,
            amount_paid,
            transaction_due_date,
            gl_account
        FROM
            transactions
        WHERE
            ref_no = '".$ref_no."'
        AND
            transaction_no = '".$transaction_no."'";
    // Create DB connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } 
    



$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $vt_id = $row["ID"];
        
        $record_row = "<tr><td>" . $row["ref_no"] . "</td><td>&nbsp;</td><td>" . $row["transaction_no"] . "</td><td>" . $row["bill_to"] . "</td><td>&nbsp;</td><td>" . $row["description"] . "</td><td>" . $row["transaction_due_date"] . "</td><td>" . number_format($row["amount"],2,'.', ',') . "</td><td>" . number_format($row["amount"],2,'.', ',') . "</td><td><input type=\"text\" class=\"input-sm form-control\" value=\"" . number_format($row["amount"],2,'.', ',') . "\" style=\"width:100px;\" /></td><td><select class=\"form-control input-sm\"><option>Select...</option><option>Credit Card</option><option>Debit Card</option></select></td></tr>";
        }
    } else {
        echo "0 results";
    }
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
    <head></head>
    <body>
        <?php echo "<table border=1>" . $record_row . "</table>"; ?>
        <form action="add2cart.php" method="post">
            <input type="hidden" name="ID" value="<?php echo $vt_id; ?>">
            <button type="submit" value="Add" name="Add">Add</button>
        </form>
    </body>
</html>