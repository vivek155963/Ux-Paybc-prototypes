<!DOCTYPE html>
<html lang="en">
<head><title>search</title></head>
<body>

<form action="pdo.php" method="POST">
<input id="ref_no" name="ref_no" class="form-control" placeholder="ABCD" type="text">
<input id="transaction_no" name="transaction_no" type="text" class="form-control"  placeholder="12345">
<button id="" class="btn btn-primary form-control" type="submit">Find my Invoice</button>
</form>

</body>
</html>
