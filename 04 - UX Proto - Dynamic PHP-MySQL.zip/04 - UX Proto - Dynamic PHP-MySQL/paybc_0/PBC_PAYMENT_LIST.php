<?php
//local
//    mysql_connect("localhost", "root", "") or die("Error connecting to database: ".mysql_error());
//aws
	mysql_connect("localhost", "root", "awesomesauce!") or die("Error connecting to database: ".mysql_error());
    mysql_select_db("paybc_as_is") or die(mysql_error());

session_start();
        if ((isset($_SESSION))==0){
            echo "Session Does not Exist. Creating...<br>";
            $_SESSION[]=array(); // Declaring session array
            $user_session_id = session_id();
        } else {    
            $user_session_id = session_id();
            //echo "Session Exists <br>";
            //echo "Session ID: <strong>" . $user_session_id . "</strong><br>";
        }


// Create the cart query
        $raw_results = mysql_query( //construct the query
        "SELECT
            vt_ID, inv_pmt_amt
        FROM
            cart
        WHERE
            session_id = '".$user_session_id."'"
        ) or die(mysql_error());
// how many results were returned?
$num_rows = mysql_num_rows($raw_results);
$pmt_total = 0.0;
$cart_rows = "";

//zero-length results are usually a a special case    
if (mysql_num_rows($raw_results) == 0){   
    $cart_rows = "<tr><td colspan=\"12\">There are no items in your cart</td></tr>"; // here's the empty variable for Cart Rows
}else{
    // our query returned at least one result. loop over results and do stuff.
    while($row = mysql_fetch_assoc($raw_results)){
        //echo $row['vt_ID'] . "....<br>";
        $temp = $row['vt_ID'];
        $pmt_amt = $row['inv_pmt_amt'];
        
        //for each of the rows returned, build a query of the ID
        $vt_results = mysql_query( //construct the query
        "SELECT
            *
        FROM
            transactions
        WHERE
            ID = '".$temp."'"
        ) or die(mysql_error());
        $vt_row = mysql_fetch_assoc($vt_results);
        $temp_row = "<tr><td><button type=\"submit\" class=\"btn btn-danger btn-xs\" title=\"Remove this item from the Payment List\" name=\"ID\" value=\"". $temp ."\"><i class=\"fa fa-close\"></i></button></td><td>" . $vt_row['ref_no'] . "</td><td>" . $vt_row['consolidated_invoice_no'] . "</td><td>" . $vt_row['transaction_no'] . "</td><td>" . $vt_row['bill_to'] . "</td><td>" . $vt_row['customer_no'] . "</td><td>" . $vt_row['description'] . "</td><td>" . $vt_row['transaction_due_date'] . "</td><td>" . number_format($vt_row['amount'],2,'.', ',') . "</td><td>" . number_format($vt_row['amount'],2,'.', ',') . "<td><input type=\"text\" class=\"input-sm form-control\" name=\"var_pmt\" disabled class=\"disabled\" value=\"". number_format($pmt_amt,2,'.', ',') . "\" style=\"width:100px;\" /></td>" . "<td>Credit Card</td>" . "</td></tr>";
        $cart_rows = $cart_rows . $temp_row;
        $pmt_total = $pmt_total + $pmt_amt;
        //echo $cart_rows;
    }
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1" .0>
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="apple-touch-icon" sizes="57x57" href="icons/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="icons/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="icons/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="icons/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="icons/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="icons/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="icons/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="icons/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192" href="icons/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="icons/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="icons/favicon-16x16.png">
    <link rel="manifest" href="icons/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="icons/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">

    <title>PayBC - Province of British Columbia</title>

    <!-- Bootstrap core CSS v3.3.6 -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link rel="stylesheet" href="css/ie10-viewport-bug-workaround.css" />

    <!-- Standard CSS -->
    <link type="text/css" href="http://www2.gov.bc.ca/StaticWebResources/static/gov3/css/main.css?refresh=160106102" rel="stylesheet" />

    <!-- Fonts -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

    <!-- Custom PayBC CSS -->
    <link href="css/paybc-main.css" rel="stylesheet" />
    <link href="css/paybc-form.css" rel="stylesheet" />
    <link href="css/tabs-left.css" rel="stylesheet" />
    <link href="css/paybc-components.css" rel="stylesheet" />
    <link href="css/PBCSCN006.css" rel="stylesheet" />
    <!-- DATATABLES CSS -->
    <link href="css/dataTables.bootstrap.min.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
    <!-- Header -->
    <div id="header">
        <div id="header-main" class="navbar navbar-default navbar-fixed-top">
            <div class="container">
                <div id="header-main-row1" class="row">
                    <!-- GOV & PAYBC LOGOS -->
                    <div class="col-sm-5 header-main-left">
                        <div id="logo">
                            <a href="index.html"><img src="http://www2.gov.bc.ca/StaticWebResources/static/gov3/images/homepage/gov3_bc_logo.png" alt="Government of B.C." title="Government of B.C." /></a>
                        </div>
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar">
                            <img src="http://www2.gov.bc.ca/StaticWebResources/static/gov3/images/mini-menu/menu-open-mobile.png" />
                        </button>
                        <a href="PBC_HOME.php"><img src="img/PayBC-logo-sm.png" id="paybc-logo" alt="PayBC Logo" title="PayBC Logo" /></a>
                    </div><!-- /GOV & PAYBC LOGOS -->
                    <!-- PAYMENT LIST & LOGOUT BUTTONS -->
                    <div class="hidden-xs col-sm-7 header-main-right text-right">
                        <!--<label class="paybc-username"><i class="fa fa-lock"></i>&nbsp;IDIR\PSMITH</label>-->
                        <a href="" class="btn btn-sm btn-success paybc-authenticate">Sign In</a>
                        <!--<a href="PBCSCN001.html" class="btn btn-sm btn-warning paybc-authenticate">Sign Out</a>-->
                    </div><!-- PAYMENT LIST BUTTON -->
                    <!-- COLLAPSING NAVBAR -->
                    <div id="navbar" class="collapse navbar-collapse">
                        <div class="row visible-xs paybc-user">
                            <!--<div class="col-xs-4 col-xs-offset-8 text-center">
                                <label class="paybc-username"><i class="fa fa-lock"></i>&nbsp;IDIR\PSMITH</label>
                            </div>-->
                            <div class="col-xs-8">
                                <a role="button" class="btn btn-default btn-block paybc-pmt-list">Payment List</a>
                            </div>
                            <div class="col-xs-4">
                                <!--<a role="button" class="btn btn-warning btn-block paybc-authenticate">Sign Out</a>-->
                                <a role="button" class="btn btn-success btn-block paybc-authenticate" href="">Sign In</a>
                            </div>
                        </div>
                        <ul class="nav navbar-nav">
                            <li><a href="PBC_HOME.php">PayBC Home</a></li>
                            <li><a href="PBC_SEARCH.php">PayBC Quick-Pay</a></li>
                            <li><a href="">FAQ</a></li>
                        </ul>
                    </div><!-- /COLLAPSING NAVBAR -->
                </div>
            </div>
            <div class="navigationRibbon">
                <div class="level2Navigation">
                    <div class="container">
                        <a href="PBC_HOME.php">PayBC Home</a>
                        <a href="PBC_SEARCH.php">PayBC Quick-Pay</a>
                        <a href="">FAQ</a>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- /Header -->
    <!-- BODY CONTENT -->
    <div id="subthemeTemplate" class="template container paybc-container">

        <div id="breadcrumbContainer">
            <ol class="breadcrumb">
                <li>
                    <a href="PBC_HOME.php">PayBC Home</a>
                </li>
                <li>
                    Payment List
                </li>
            </ol>
        </div>
        <a id="main-content-anchor"></a>

        <div class="row">
            <div id="main-content" class="contentPageMainColumn col-xs-12">
                <h1>Your Payment List: <small> Review the items in your Payment List before proceeding to payment.</small></h1>
                <div id="pageIntro">
                    <div class="row">
                        <div class="col-sm-5 col-md-3">
                            <a href="PBC_SEARCH.php" class="btn btn-info btn-block"><i class="fa fa-search"></i>&nbsp;&nbsp;Add more Quick-Pay Items</a>
                            <br class="visible-xs" />
                        </div>
                    </div>
                </div>
                <!-- <div class="row">
                    <div class="col-lg-12">
                        <div class="paybc-alert paybc-alert-success payment-list-alert text-center">
                            <i class="fa fa-check-circle"></i> <strong>You have added 1 item to your Payment List.</strong><br class="hidden-lg" /> Review these items before proceeding to Payment.

                        </div>
                    </div>
                </div>-->
                <div class="panel panel-paybc">
                    
                    <div class="panel-heading">
                        <h3 class="panel-title"><i class="fa fa-list"></i> Payment List</h3>

                        <div class="clearfix"></div>
                    </div>
                    <form action="PBC_CART_OPS.php" method="post">
                        <input type="hidden" name="CART_ACTION" value="REMOVE">
                    <div class="table-responsive paybc-payment-list">
                        <table id="PBCSCN006-1" class="table table-condensed table-striped table-bordered table-hover paybc-payment-list">
                            <thead>
                                <tr>
                                    <th>&nbsp;</th>
                                    <th class="hidden-xs">Ref. No.</th>
                                    <th class="hidden-md hidden-sm hidden-xs"><abbr title="Consolidated Invoice Number">C.I. #</abbr></th>
                                    <th>Invoice #</th>
                                    <th>Customer Name</th>
                                    <th class="hidden-sm hidden-xs">Customer #</th>
                                    <th class="hidden-sm hidden-xs">Invoice<br />Desc.</th>
                                    <th class="hidden-sm hidden-xs">Invoice<br />Due Date</th>
                                    <th class="hidden-md hidden-sm hidden-xs">Original<br />Amount</th>
                                    <th class="hidden-xs">Outstanding<br />Amount</th>
                                    <th>Payment<br />Amount<br /><small class="visible-xs">(click to edit)</small></th>
                                    <th>Payment<br />Type</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php echo $cart_rows; ?>
                            </tbody>
                        </table>

                    </div>
                    </form>
                    <div class="panel-footer">
                        <a href="" class="btn btn-default btn-sm pull-left" title="Export Payment List"><i class="fa fa-download"></i> Export Payment List</a>
                        <br class="visible-xs" /><br class="visible-xs" />
                        <div class="form-inline pull-right">
                            <div class="form-group">
                                <label for="totalAmount">Total:&nbsp;&nbsp;</label>
                                <label class="sr-only" for="totalAmount">Amount (in dollars)</label>
                                <div class="input-group">
                                    <div class="input-group-addon">$</div>
                                    <input name="total" type="text" class="form-control input-total disabled" disabled id="total" value="<?php echo number_format($pmt_total,2,'.', ','); ?>">
                                </div>
                                <a href="Beanstream-Hosted.html" class="btn btn-success pull-right" title="Proceed to Payment">Proceed to Credit Card Payment</a>
                            </div>
                        </div><br />
                        <div class="clearfix"></div>
                        <div class="text-right"><p>Payments made after 9pm, or on weekends, or on statutory holidays will be recognized as being made on the following business day. <br />Please note that it can take up to 24 hours for your payment to be applied to your account.<br />For more information on Payment Processing, please <a href="">visit the FAQ</a>.</p></div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
    <!-- /BODY CONTENT -->
    <!-- FOOTER -->
    <div id="footer">
        <div id="footerWrapper">
            <div id="footerAdminSection">
                <div id="footerAdminLinksContainer" class="container">
                    <div id="footerAdminLinks" class="row">
                        <ul class="inline">
                            <li>
                                <a href="#" target="_self">Home</a>
                            </li>
                            <li>
                                <a href="#" target="_self">About pay.gov.bc.ca</a>
                            </li>
                            <li>
                                <a href="#" target="_self">Disclaimer</a>
                            </li>
                            <li>
                                <a href="#" target="_self">Privacy</a>
                            </li>
                            <li>
                                <a href="#" target="_self">Accessibility</a>
                            </li>
                            <li>
                                <a href="#" target="_self">Copyright</a>
                            </li>
                            <li>
                                <a href="#" target="_self">Contact Us</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /FOOTER -->
    <!-- Modals -->
    <!-- Invoice Detail Modal Example -->
    <div id="invoice-detail" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Invoice #6122 Detail</h4>
                </div>
                <div class="modal-body">
                    <dl class="dl-horizontal">
                        <dt>Organization ID:</dt>
                        <dd>R123</dd>
                        <dt>Organization Name:</dt>
                        <dd>Ministry of Finance</dd>
                        <dt>Invoice #:</dt>
                        <dd>6122</dd>
                        <dt>Outstanding Amount:</dt>
                        <dd>CDN$ 236.25</dd>
                        <dt>Customer Name:</dt>
                        <dd>Pat Smith</dd>
                        <dt>Invoice Desc:</dt>
                        <dd>Service Fee</dd>
                        <dt>Site ID:</dt>
                        <dd>987-654-321</dd>
                        <dt>Invoice Due Date:</dt>
                        <dd>30/03/2016</dd>
                        <dt>Original Invoice Amount:</dt>
                        <dd>CDN$ 236.25</dd>
                        <dt>Outstanding Invoice Amount</dt>
                        <dd>CDN$ 236.25</dd>

                    </dl>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    <!-- /Invoice Detail Modal Example -->
    <!-- Payment Update Modal Example -->
    <div id="payment-update" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Edit Payment Amount</h4>
                </div>
                <div class="modal-body">
                    
                        <div class="form-group">
                            <label for="outstanding-amount">Outstanding Amount</label>
                            <div class="input-group">
                                <div class="input-group-addon">$</div>
                                <input type="text" class="form-control" id="outstanding-amount" placeholder="$0.00" value="236.25">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="amount-to-pay">Amount to Pay</label>
                            <div class="input-group">
                                <div class="input-group-addon">$</div>
                                <input type="text" class="form-control" id="amount-to-pay" placeholder="$0.00" value="236.25">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" type="button">Pay All</button>
                                </span>
                            </div>
                        </div>
                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Save changes</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    <!-- /Payment Update Modal Example -->
    <!-- /Modals -->
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <!--<script src="http://www2.gov.bc.ca/StaticWebResources/static/gov3/js/misc.js"></script>-->
    <!--<script src="js/misc.js"></script>-->
    <!--<script src="http://www2.gov.bc.ca/StaticWebResources/static/gov3/js/navMenu.js"></script>-->
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/ie10-viewport-bug-workaround.js"></script>


    <!-- DATATABLES SCRIPTS -->
    <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.10/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.10/js/dataTables.bootstrap.min.js"></script>

    <!-- Datatables config -->
    <script>
        $(function () {
            $('[data-toggle="tooltip"]').tooltip()
        })
    </script>
    <script type="text/javascript" charset="utf-8">
        $(document).ready(function () {
            $('#PBCSCN006-1').DataTable({
                "lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]],
                "order": [[1, "asc"]],
                "aoColumns": [
                                    { "bSortable": false },
                                    { "bSortable": true },
                                    { "bSortable": true },
                                    { "bSortable": true },
                                    { "bSortable": true },
                                    { "bSortable": true },
                                    { "bSortable": true },
                                    { "bSortable": true },
                                    { "bSortable": true },
                                    { "bSortable": true },
                                    { "bSortable": true },
                                    { "bSortable": false },
                                    { "bSortable": false }]
            });

        });

    </script>

    <script>

  function sum() {
    var inputs = document.getElementsByTagName('var_pmt'),
        result = document.getElementById('total'),
        sum = 0;            

    for(var i=0; i<inputs.length; i++) {
        var ip = inputs[i];

        if (ip.name && ip.name.indexOf("total") < 0) {
            sum += parseInt(ip.value) || 0;
        }

    }

    result.value = sum;
}

</script>
    
    <script>
        $(function () {
            $('[data-toggle="tooltip"]').tooltip()
        })
    </script>
</body>

</html>
