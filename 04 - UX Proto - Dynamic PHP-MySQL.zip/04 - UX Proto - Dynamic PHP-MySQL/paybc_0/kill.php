<html>
<body>
<?php 
session_start();
unset($_SESSION);
    session_destroy();
echo "KILLED!";

//remove all records from the CART table, so we can start again
//local
//    mysql_connect("localhost", "root", "") or die("Error connecting to database: ".mysql_error());
//aws
	mysql_connect("localhost", "root", "awesomesauce!") or die("Error connecting to database: ".mysql_error());
mysql_select_db("paybc_as_is") or die(mysql_error());
$raw_results = mysql_query("truncate cart");

phpinfo();    
    
?>

</body>
</html>