<?php
    session_start();
        if ((isset($_SESSION))==0){
            echo "Session Does not Exist. Creating...<br>";
            $_SESSION[]=array(); // Declaring session array
        } else {    
            $user_session_id = session_id();
            echo "Session Exists <br>";
            echo "Session ID: <strong>" . $user_session_id . "</strong><br>";
        }


    // get the search variables from calling form
    $add_ID = $_POST['ID'];
    // debug echo to page
    echo "<br>This is the ID passed from the form: <strong>" . $add_ID . "</strong><br>";


    // create database connection variables
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "paybc_as_is";
    
    //create SQL query
    $sql = "SELECT
            ID,
            session_ID,
            vt_ID,
            inv_no
        FROM
            cart
        WHERE
            vt_ID = '".$add_ID."' and session_ID = '".$user_session_id."'";
    



    // Create DB connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } 
    
    $result=mysqli_query($conn,$sql);
    

    if ($result->num_rows > 0) {
        // output data of each row
        echo "Results are greater than 0<br>";
        echo "Build the SQL statement to get the details from the TRANSACTIONS table <br>";
        $sql_vt_info = "SELECT
            ID,
            ref_no,
            transaction_date,
            consolidated_invoice_no,
            transaction_no,
            customer_no,
            bill_to,
            description,
            amount,
            amount_paid,
            transaction_due_date
        FROM
            transactions
        WHERE
            transaction_no = '".$add_ID."'";
        
        echo "Run the query <br>";
        $result_vt_info=mysqli_query($conn,$sql_vt_info);
        
        while($row = $result->fetch_assoc()) {
            $current_ID = $row["vt_ID"];
            echo "hello?<br>";
            $record_row = "<table border=1><tr><td> - this is the vt_ID: " . $current_ID . "</td></tr></table>";
            echo $record_row . "<br>";
            }
        } else {
            echo "0 results - so lets add some!<br>";
            //$insert = "INSERT INTO cart (session_id, vt_ID) VALUES ('$user_session_id', '$add_ID' )";
        
        
if ($result = mysqli_query($link, $query)) {

    /* fetch associative array */
    while ($row = mysqli_fetch_assoc($result)) {
        printf ("%s (%s)\n", $row["Name"], $row["CountryCode"]);
    }

    /* free result set */
    mysqli_free_result($result);
}
        
        
        
        
        
            //echo "ref_no: " . $result_vt_info["ref_no"] . "<br>";
        
        
            //$insert = "INSERT INTO cart (session_id, vt_ID, ref_no, ci_no, inv_no, cust_no, cust_name, inv_desc, inv_due_date, inv_orig_amt, inv_out_amt, inv_pmt_amt, inv_pmt_type) 
             //               VALUES ('$user_session_id', '$add_ID', '$result_vt_info['ref_no']'  )";
        
           // if (mysqli_query($conn,$insert) === TRUE) {
           //     echo "New record created successfully";
          //  } else {
          //      echo "Error: " . $insert . "<br>" . $conn->error;
         //   }
        }

        
        $conn->close();
    //off to view payment list
             //header("Location: paymentlist.php");
             //die();

    
       

?>