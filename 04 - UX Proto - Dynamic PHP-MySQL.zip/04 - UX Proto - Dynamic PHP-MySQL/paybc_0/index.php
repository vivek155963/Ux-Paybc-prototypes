
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1" .0>
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="apple-touch-icon" sizes="57x57" href="icons/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="icons/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="icons/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="icons/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="icons/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="icons/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="icons/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="icons/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192" href="icons/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="icons/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="icons/favicon-16x16.png">
    <link rel="manifest" href="icons/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="icons/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">

    <title>RSI Violations Portal Prototype</title>

    <!-- Bootstrap core CSS v3.3.6 -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link rel="stylesheet" href="css/ie10-viewport-bug-workaround.css" />

    <!-- Standard CSS -->
    <link type="text/css" href="http://www2.gov.bc.ca/StaticWebResources/static/gov3/css/main.css?refresh=160106102" rel="stylesheet" />

    <!-- Fonts -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

    <!-- Custom PayBC CSS -->
    <link href="css/paybc-main.css" rel="stylesheet" />
    <link href="css/paybc-form.css" rel="stylesheet" />
    <link href="css/paybc-demo.css" rel="stylesheet" />


    <!-- DATATABLES CSS -->
    <link href="css/dataTables.bootstrap.min.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
    <!-- Header -->
    <div id="header">
        <div id="header-main" class="navbar navbar-default navbar-fixed-top">
            <div class="container">
                <div id="header-main-row1" class="row">
                    <!-- GOV & PAYBC LOGOS -->
                    <div class="col-sm-5 header-main-left">
                        <div id="logo">
                            <a href="#"><img src="http://www2.gov.bc.ca/StaticWebResources/static/gov3/images/homepage/gov3_bc_logo.png" alt="Government of B.C." title="Government of B.C." /></a>
                        </div>
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar">
                            <img src="http://www2.gov.bc.ca/StaticWebResources/static/gov3/images/mini-menu/menu-open-mobile.png" />
                        </button>
                        <a href="index.html"><img src="img/RSI-logo-sm.png" id="paybc-logo" alt="RSI Logo" title="RSI Logo" /></a>
                    </div><!-- /GOV & PAYBC LOGOS -->
                    <!-- PAYMENT LIST & LOGOUT BUTTONS -->
                    <div class="hidden-xs col-sm-7 header-main-right text-right">

                    </div><!-- PAYMENT LIST BUTTON -->
                    <!-- COLLAPSING NAVBAR -->
                    <div id="navbar" class="collapse navbar-collapse">
                        <!--<div class="row visible-xs paybc-user">
                            <div class="col-xs-4 col-xs-offset-8 text-center">
                            </div>
                            <div class="col-xs-8">
                            </div>
                            <div class="col-xs-4">
                            </div>
                        </div>-->
                        <ul class="nav navbar-nav">
                            <li><a href="#">RSI Violations Portal Home</a></li>
                            <li><a href="#">Options</a></li>
                            <li><a href="#">FAQ</a></li>
                        </ul>
                    </div><!-- /COLLAPSING NAVBAR -->
                </div>
            </div>
            <div class="navigationRibbon">
                <div class="level2Navigation">
                    <div class="container">
                        <a href="#">RSI Violations Portal Home</a>
                        <a href="#">Options</a>
                        <a href="#">FAQ</a>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- /Header -->
    <!-- BODY CONTENT -->
    <div id="subthemeTemplate" class="template container paybc-container">
        <!--<div id="paybc-user-container">
            <a href="#" class="btn btn-primary btn-sm paybc-pmt-list">View Payment List <span class="paybe-pmt-list-total">($2,345.67)</span></a>
        </div>-->


        <div class="row">
            <div id="main-content" class="contentPageMainColumn col-xs-12">
                <div class="row">
                    <div class="col-xs-12">
                        <br />
                        <div class="panel panel-paybc">
                            <div class="panel-heading">
                                <h3 class="panel-title">RSI Violations Portal</h3>
                            </div>
                            <form action="search.php" method="POST">
                            <div class="panel-body">
                                <br /><br />
                                <div class="row">
                                    <!--<p>Something about admission of guilt and now that by paying they're admitting guilt.</p>-->
                                    <div class="form-group col-xs-12 col-sm-4 col-md-3 col-md-offset-3">
                                        <label for="contribution-value">Violation Ticket Number</label>
                                        <input class="form-control" id="invoice-number" placeholder="A12345678C" type="text" name="query" maxlength="10" required>
                                    </div>
                                    <div class="form-group col-xs-12 col-sm-4 col-md-3">
                                        <label>&nbsp;</label>
                                        <button id="" class="btn btn-primary form-control" type="submit">Search</a>
                                    </div>
                                    <div class="form-group col-xs-12 col-sm-4 col-md-6 col-md-offset-3">
                                    <div class="help-block">Sample data: AH12345678, AD85274169, AD50109663, AB97641325, AA96325874</div></div>
                                </div>
                                <br /><br />
                            </div>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /BODY CONTENT -->
    <!-- FOOTER -->
    <div id="footer">
        <div id="footerWrapper">
            <div id="footerAdminSection">
                <div id="footerAdminLinksContainer" class="container">
                    <div id="footerAdminLinks" class="row">
                        <ul class="inline">
                            <li>
                                <a href="#" target="_self">Footer Link</a>
                            </li>
                            <li>
                                <a href="#" target="_self">Footer Link</a>
                            </li>
                            <li>
                                <a href="#" target="_self">Footer Link</a>
                            </li>
                            <li>
                                <a href="#" target="_self">Footer Link</a>
                            </li>
                            <li>
                                <a href="#" target="_self">Footer Link</a>
                            </li>
                            <li>
                                <a href="#" target="_self">Footer Link</a>
                            </li>
                            <li>
                                <a href="#" target="_self">Footer Link</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /FOOTER -->
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/ie10-viewport-bug-workaround.js"></script>


</body>
</html>
