<?php
session_start();
        if ((isset($_SESSION))==0){
            echo "Session Does not Exist. Creating...<br>";
            $_SESSION[]=array(); // Declaring session array
            $user_session_id = session_id();
        } else {    
            $user_session_id = session_id();
            echo "Session Exists <br>";
            echo "Session ID: <strong>" . $user_session_id . "</strong><br>";
        }

// create database connection variables
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "paybc_as_is";
    
//create SQL query
    $sql = "SELECT * FROM cart WHERE session_id = '".$user_session_id."'";

// Create DB connection
    $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
    if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
//$result = $conn->query($sql);

    if($result=mysqli_query($conn,$sql)) {
        /* fetch associative array */
        while ($row = mysqli_fetch_assoc($result)) {
            printf ("%s (%s)\n", $row["session_id"], $row["vt_ID"]);
        }
        /* free result set */
        mysqli_free_result($result);
    }

    $conn->close();

?>