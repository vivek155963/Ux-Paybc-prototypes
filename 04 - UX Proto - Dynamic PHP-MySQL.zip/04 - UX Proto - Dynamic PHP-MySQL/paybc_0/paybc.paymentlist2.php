<?php 
//check for session_id
if ((isset($_SESSION[]))==0) {
    echo "no session<br>";
    
} else {
    session_start();
    
}
echo session_id();



// - if no session_id, then create one
// - if session_id, query DB for cart based on session_id
//		- if no cart in DB
//			- tough luck
//		- if cart in DB
//			- loop over cart rows and print cart to page


?>