
<?php
session_start();
        if ((isset($_SESSION))==0){
            echo "Session Does not Exist. Creating...<br>";
            $_SESSION[]=array(); // Declaring session array
            $user_session_id = session_id();
        } else {    
            $user_session_id = session_id();
            echo "Session Exists <br>";
            echo "Session ID: <strong>" . $user_session_id . "</strong><br>";
        }

//        $CART_ACTION = mysql_real_escape_string(htmlspecialchars($_POST['CART_ACTION'])); // Escapes special characters
//       $ID = mysql_real_escape_string(htmlspecialchars($_POST['ID'])); // Escapes special characters
//        $amount_to_pay = mysql_real_escape_string(htmlspecialchars($_POST['amount_to_pay'])); // Escapes special characters
//        $pmt_type = mysql_real_escape_string(htmlspecialchars($_POST['pmt_type'])); // Escapes special characters

        $CART_ACTION = $_POST['CART_ACTION']; // Escapes special characters
        $ID = $_POST['ID']; // Escapes special characters
        $amount_to_pay = $_POST['amount_to_pay']; // Escapes special characters
        $pmt_type = $_POST['pmt_type']; // Escapes special characters

//confirm form data
    echo "ID: " . $ID . " ... Amount: " . $amount_to_pay . " ... Type: " . $pmt_type . " ... CART_ACTION: " . $CART_ACTION;

//check the CART_ACTION variable to see what we're trying to do
// e.g., are we "adding", "removing" or the default case, which is to do nothing
switch($CART_ACTION) {
        
    case 'ADD':
        
            //query the CART table to see if an entry exists for the current SESSION_ID and invoice ID
            //connect to DB
//local
//    mysql_connect("localhost", "root", "") or die("Error connecting to database: ".mysql_error());
//aws
	mysql_connect("localhost", "root", "awesomesauce!") or die("Error connecting to database: ".mysql_error());
            mysql_select_db("paybc_as_is") or die(mysql_error());
            //construct the variables
            $cart_sql = "SELECT * FROM cart WHERE session_id = '".$user_session_id."' and vt_ID = '".$ID."'";
            //run the query
            $cart_results = mysql_query($cart_sql) or die(mysql_error());
            //check if a row with the session and vt_ID exists
            if(mysql_num_rows($cart_results) > 0){ // if one or more rows are returned do following

                    echo "Already in cart";

                    }

                else{ // if there is no matching rows
                    //then we build the insert query
                    $cart_insert_sql = "INSERT into cart (session_id, vt_ID, inv_pmt_amt, inv_pmt_type) values ('$user_session_id', '$ID', '$amount_to_pay', '$pmt_type')";
                    //and insert the new record into the CART table
                    $cart_insert = mysql_query($cart_insert_sql) or die(mysql_error());

                }    
                
        header('Location: PBC_PAYMENT_LIST.php');
        break;
        
        
        
        
        
    case 'REMOVE':
        echo "<br>removing...: " . $ID . "<br>";
        
        //query the CART table to see if an entry exists for the current SESSION_ID and invoice ID
            //connect to DB
//local
//    mysql_connect("localhost", "root", "") or die("Error connecting to database: ".mysql_error());
//aws
	mysql_connect("localhost", "root", "awesomesauce!") or die("Error connecting to database: ".mysql_error());
            mysql_select_db("paybc_as_is") or die(mysql_error());
            //construct the variables
            $cart_sql = "DELETE FROM cart WHERE session_id = '".$user_session_id."' and vt_ID = '".$ID."'";
            //run the query
            $cart_results = mysql_query($cart_sql) or die(mysql_error());
        header('Location: PBC_PAYMENT_LIST.php');
        break;
    default:
        echo "<h1>Nothing to do here...</h1>";
    break;

}

?>
<br><br>
<a href="PBC_PAYMENT_LIST.php">Payment List</a>