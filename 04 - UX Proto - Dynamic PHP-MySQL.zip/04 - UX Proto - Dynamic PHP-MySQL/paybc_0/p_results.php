<?php
    mysql_connect("localhost", "root", "") or die("Error connecting to database: ".mysql_error());
    /*
        if connection fails it will stop loading the page and display an error
    */

    mysql_select_db("paybc_as_is") or die(mysql_error());
// get the search variables from calling form
    $ref_no = $_POST['ref_no'];
    $transaction_no = $_POST['transaction_no'];
    // gets value sent over search form

        //$ref_no = htmlspecialchars($ref_no); //Convert special characters to HTML entities
        $ref_no = mysql_real_escape_string(htmlspecialchars($ref_no)); // Escapes special characters
        //$transaction_no = htmlspecialchars($transaction_no); //Convert special characters to HTML entities
        $transaction_no = mysql_real_escape_string(htmlspecialchars($transaction_no)); // Escapes special characters

        $raw_results = mysql_query( //construct the query
        "SELECT
            ID,
            ref_no,
            transaction_source,
            transaction_date,
            consolidated_invoice_no,
            transaction_no,
            customer_no,
            class,
            type,
            bill_to,
            description,
            quantity,
            uom,
            amount,
            amount_paid,
            transaction_due_date,
            gl_account
        FROM
            transactions
        WHERE
            ref_no = '".$ref_no."'
        AND
            transaction_no = '".$transaction_no."'"
        ) or die(mysql_error());


        if(mysql_num_rows($raw_results) > 0){ // if one or more rows are returned do following

            while($results = mysql_fetch_array($raw_results)){
            // $results = mysql_fetch_array($raw_results) puts data from database into array, while it's valid it does the loop
            //build the results table
            $ID =                       $results['ID'];
            $ref_no =                   $results['ref_no'];
            $transaction_source =       $results['transaction_source'];
            $transaction_date =         $results['transaction_date'];
            $consolidated_invoice_no =  $results['consolidated_invoice_no'];
            $transaction_no =           $results['transaction_no'];
            $customer_no =              $results['customer_no'];
            $class =                    $results['class'];
            $type =                     $results['type'];
            $bill_to =                  $results['bill_to'];
            $description =              $results['description'];
            $quantity =                 $results['quantity'];
            $uom =                      $results['uom'];
            $amount =                   $results['amount'];
            $amount_paid =              $results['amount_paid'];
            $transaction_due_date =     $results['transaction_due_date'];
            $gl_account =               $results['gl_account'];

            }

        }
        else{ // if there is no matching rows do following
            echo "<div class=\"alert alert-info\" role=\"alert\"><strong>No results</strong> Please check your Violation Ticket Number and try again.</div>";
        }
echo $description;
?>