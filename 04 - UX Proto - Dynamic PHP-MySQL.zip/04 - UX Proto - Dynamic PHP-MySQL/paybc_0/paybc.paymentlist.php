<?php

        session_start();
        //If the "cart" session variable doesn't exist...
        if ((isset($_SESSION['cart']))==0)
        {
            //echo "<!-- ARRRGH!!!!! - no Session array -->";
        }
       if (isset($_SESSION['cart']))
        {
            //loop over all the items in the array
           foreach ($_SESSION['cart'] as $key => $value)
            {
                //print_r($_SESSION['cart']);
                //echo $key . "=" . $value . "<br>";
            }
           //echo session_id();
        }     

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1" .0>
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="apple-touch-icon" sizes="57x57" href="icons/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="icons/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="icons/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="icons/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="icons/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="icons/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="icons/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="icons/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192" href="icons/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="icons/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="icons/favicon-16x16.png">
    <link rel="manifest" href="icons/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="icons/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">

    <title>PayBC - Province of British Columbia</title>

    <!-- Bootstrap core CSS v3.3.6 -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link rel="stylesheet" href="css/ie10-viewport-bug-workaround.css" />

    <!-- Standard CSS -->
    <link type="text/css" href="http://www2.gov.bc.ca/StaticWebResources/static/gov3/css/main.css?refresh=160106102" rel="stylesheet" />

    <!-- Fonts -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

    <!-- Custom PayBC CSS -->
    <link href="css/paybc-main.css" rel="stylesheet" />
    <link href="css/paybc-form.css" rel="stylesheet" />
    <link href="css/tabs-left.css" rel="stylesheet" />
    <link href="css/paybc-components.css" rel="stylesheet" />
    <link href="css/PBCSCN006.css" rel="stylesheet" />
    <!-- DATATABLES CSS -->
    <link href="css/dataTables.bootstrap.min.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
<?php
    while (list ($key, $val) = each ($_SESSION['cart'])) { 
        //echo "$key -> $val <br>";
    }

?>
    <!-- Header -->
    <div id="header">
        <div id="header-main" class="navbar navbar-default navbar-fixed-top">
            <div class="container">
                <div id="header-main-row1" class="row">
                    <!-- GOV & PAYBC LOGOS -->
                    <div class="col-sm-5 header-main-left">
                        <div id="logo">
                            <a href="#"><img src="http://www2.gov.bc.ca/StaticWebResources/static/gov3/images/homepage/gov3_bc_logo.png" alt="Government of B.C." title="Government of B.C." /></a>
                        </div>
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar">
                            <img src="http://www2.gov.bc.ca/StaticWebResources/static/gov3/images/mini-menu/menu-open-mobile.png" />
                        </button>
                        <a href="PBCSCN001-u-rsi.html"><img src="img/PayBC-logo-sm.png" id="paybc-logo" alt="PayBC Logo" title="PayBC Logo" /></a>
                    </div>
                    <!-- /GOV & PAYBC LOGOS -->
                    <!-- PAYMENT LIST & LOGOUT BUTTONS -->
                    <div class="hidden-xs col-sm-7 header-main-right text-right">
                        <!--<label class="paybc-username"><i class="fa fa-lock"></i>&nbsp;IDIR\PSMITH</label>-->
                        <a href="#" class="btn btn-default btn-sm paybc-pmt-list">Payment List <span class="paybe-pmt-list-total">($236.25)</span></a>
                        <a href="PBCSCN002.html" class="btn btn-sm btn-success paybc-authenticate">Sign In</a>
                        <!--<a href="PBCSCN001.html" class="btn btn-sm btn-warning paybc-authenticate">Sign Out</a>-->
                    </div>
                    <!-- PAYMENT LIST BUTTON -->
                    <!-- COLLAPSING NAVBAR -->
                    <div id="navbar" class="collapse navbar-collapse">
                        <div class="row visible-xs paybc-user">
                            <!--<div class="col-xs-4 col-xs-offset-8 text-center">
                                <label class="paybc-username"><i class="fa fa-lock"></i>&nbsp;IDIR\PSMITH</label>
                            </div>-->
                            <div class="col-xs-8">
                                <a role="button" class="btn btn-default btn-block paybc-pmt-list">Payment List <span class="paybe-pmt-list-total">($236.25)</span></a>
                            </div>
                            <div class="col-xs-4">
                                <!--<a role="button" class="btn btn-warning btn-block paybc-authenticate">Sign Out</a>-->
                                <a role="button" class="btn btn-success btn-block paybc-authenticate" href="PBCSCN002.html">Sign In</a>
                            </div>
                        </div>
                        <ul class="nav navbar-nav">
                            <li><a href="PBCSCN001-u-rsi.html">PayBC Home</a></li>
                            <li><a href="PBCSCN004-u-rsi.html">PayBC Quick-Pay</a></li>
                            <li><a href="PBCFAQ.html">FAQ</a></li>
                        </ul>
                    </div>
                    <!-- /COLLAPSING NAVBAR -->
                </div>
            </div>
            <div class="navigationRibbon">
                <div class="level2Navigation">
                    <div class="container">
                        <a href="PBCSCN001-u-rsi.html">PayBC Home</a>
                        <a href="PBCSCN004-u-rsi.html">PayBC Quick-Pay</a>
                        <a href="PBCFAQ.html">FAQ</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Header -->
    <!-- BODY CONTENT -->
    <div id="subthemeTemplate" class="template container paybc-container">

        <div id="breadcrumbContainer">
            <ol class="breadcrumb">
                <li>
                    <a href="PBCSCN001-u-rsi.html">PayBC Home</a>
                </li>
                <li>
                    Payment List
                </li>
            </ol>
        </div>
        <a id="main-content-anchor"></a>

        <div class="row">
            <div id="main-content" class="contentPageMainColumn col-xs-12">
                <h1>Your Payment List: <small> Review the items in your Payment List before proceeding to payment.</small></h1>
                <div id="pageIntro">
                    <div class="row">
                        <div class="col-sm-5 col-md-3">
                            <a href="paybc.quickpaysearch.php" class="btn btn-info btn-block"><i class="fa fa-search"></i>&nbsp;&nbsp;Add more Quick-Pay Items</a>
                            <br class="visible-xs" />
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="paybc-alert paybc-alert-success payment-list-alert text-center">
                            <i class="fa fa-check-circle"></i> <strong>You have added 1 item to your Payment List.</strong><br class="hidden-lg" /> Review these items before proceeding to Payment.

                        </div>
                    </div>
                </div>
                <div class="panel panel-paybc">
                    <div class="panel-heading">
                        <h3 class="panel-title"><i class="fa fa-list"></i> Payment List<span class="pull-right"><small>Total:</small> $236.25 <small>(1 item)</small></span></h3>

                        <div class="clearfix"></div>
                    </div>
                    <div class="panel-body">

                    </div>
                    <div class="table-responsive paybc-payment-list">
                        <table id="PBCSCN006-1" class="table table-condensed table-striped table-bordered table-hover paybc-payment-list">
                            <thead>
                                <tr>
                                    <th>&nbsp;</th>
                                    <th class="hidden-xs">Ref. No.</th>
                                    <th class="hidden-md hidden-sm hidden-xs"><abbr title="Consolidated Invoice Number">C.I. #</abbr></th>
                                    <th>Invoice #</th>
                                    <th>Customer Name</th>
                                    <th class="hidden-sm hidden-xs">Customer #</th>
                                    <th class="hidden-sm hidden-xs">Invoice<br />Desc.</th>
                                    <th class="hidden-sm hidden-xs">Invoice<br />Due Date</th>
                                    <th class="hidden-md hidden-sm hidden-xs">Original<br />Amount</th>
                                    <th class="hidden-xs">Outstanding<br />Amount</th>
                                    <th>Payment<br />Amount<br /><small class="visible-xs">(click to edit)</small></th>
                                    <th>Payment<br />Type</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                <td><button type="button" class="btn btn-danger btn-xs" title="Remove this item from the Payment List" data-toggle="tooltip" data-placement="top"><i class="fa fa-close"></i></button></td>
                                <?php 
                                foreach ($_SESSION['cart'] as $key => $value)
                                    {
                                        echo "<td>". $value . "</td>";
                                    }
                                ?>
                                    <td class="hidden-xs">
                                        <input type="text" class="input-sm form-control" value="167.00" style="width:100px;" />
                                    </td>
                                    <td>Credit Card</td>
                                </tr>
                                <!-- <tr>
                                    
                                    <td class="hidden-xs">R123</td>
                                    <td class="hidden-md hidden-sm hidden-xs">n/a</td>
                                    <td><a title="Click to view invoice details" role="button" data-toggle="modal" data-target="#invoice-detail"><strong><i class="fa fa-info-circle"></i> 6122</strong></a></td>
                                    <td>Pat Smith</td>
                                    <td class="hidden-sm hidden-xs">6435</td>
                                    <td class="hidden-sm hidden-xs">Service Fee</td>
                                    <td class="hidden-sm hidden-xs">30/03/2016</td>
                                    <td class="hidden-md hidden-sm hidden-xs">236.25</td>
                                    <td class="hidden-xs">236.25</td>
                                    <td class="visible-xs">
                                        <input type="text" class="input-sm form-control" data-toggle="modal" data-target="#payment-update" value="236.25" />
                                    </td>
                                    <td class="hidden-xs">
                                        <input type="text" class="input-sm form-control" value="236.25" style="width:100px;" />
                                    </td>
                                    
                                </tr>-->


                            </tbody>
                        </table>

                    </div>
                    <div class="panel-footer">

                        <a href="PBCSCN013-u.html" class="btn btn-default btn-sm pull-left" title="Export Payment List"><i class="fa fa-download"></i> Export Payment List</a>
                        <br class="visible-xs" /><br class="visible-xs" />
                        <div class="form-inline pull-right">
                            <div class="form-group">
                                <label for="totalAmount">Total:&nbsp;&nbsp;</label>
                                <label class="sr-only" for="totalAmount">Amount (in dollars)</label>
                                <div class="input-group">
                                    <div class="input-group-addon">$</div>
                                    <input type="text" class="form-control input-total disabled" disabled id="totalAmount" placeholder="Amount" value="236.25">
                                </div>
                                <a href="Beanstream-Hosted.html" class="btn btn-success pull-right" title="Proceed to Payment">Proceed to Credit Card Payment</a>

                            </div>
                        </div><br />
                        <div class="clearfix"></div>
                        <div class="text-right">
                            <p>Payments made after 9pm, or on weekends, or on statutory holidays will be recognized as being made on the following business day. <br />Please note that it can take up to 24 hours for your payment to be applied to your account.<br
                                />For more information on Payment Processing, please <a href="/PBCFAQ.html#2">visit the FAQ</a>.</p>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /BODY CONTENT -->
    <!-- FOOTER -->
    <div id="footer">
        <div id="footerWrapper">
            <div id="footerAdminSection">
                <div id="footerAdminLinksContainer" class="container">
                    <div id="footerAdminLinks" class="row">
                        <ul class="inline">
                            <li>
                                <a href="#" target="_self">Home</a>
                            </li>
                            <li>
                                <a href="#" target="_self">About pay.gov.bc.ca</a>
                            </li>
                            <li>
                                <a href="#" target="_self">Disclaimer</a>
                            </li>
                            <li>
                                <a href="#" target="_self">Privacy</a>
                            </li>
                            <li>
                                <a href="#" target="_self">Accessibility</a>
                            </li>
                            <li>
                                <a href="#" target="_self">Copyright</a>
                            </li>
                            <li>
                                <a href="#" target="_self">Contact Us</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /FOOTER -->
    <!-- Modals -->
    <!-- Invoice Detail Modal Example -->
    <div id="invoice-detail" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Invoice #6122 Detail</h4>
                </div>
                <div class="modal-body">
                    <dl class="dl-horizontal">
                        <dt>Organization ID:</dt>
                        <dd>R123</dd>
                        <dt>Organization Name:</dt>
                        <dd>Ministry of Finance</dd>
                        <dt>Invoice #:</dt>
                        <dd>6122</dd>
                        <dt>Outstanding Amount:</dt>
                        <dd>CDN$ 236.25</dd>
                        <dt>Customer Name:</dt>
                        <dd>Pat Smith</dd>
                        <dt>Invoice Desc:</dt>
                        <dd>Service Fee</dd>
                        <dt>Site ID:</dt>
                        <dd>987-654-321</dd>
                        <dt>Invoice Due Date:</dt>
                        <dd>30/03/2016</dd>
                        <dt>Original Invoice Amount:</dt>
                        <dd>CDN$ 236.25</dd>
                        <dt>Outstanding Invoice Amount</dt>
                        <dd>CDN$ 236.25</dd>

                    </dl>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->
    <!-- /Invoice Detail Modal Example -->
    <!-- Payment Update Modal Example -->
    <div id="payment-update" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Edit Payment Amount</h4>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="form-group">
                            <label for="outstanding-amount">Outstanding Amount</label>
                            <div class="input-group">
                                <div class="input-group-addon">$</div>
                                <input type="text" class="form-control" id="outstanding-amount" placeholder="$0.00" value="236.25">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="amount-to-pay">Amount to Pay</label>
                            <div class="input-group">
                                <div class="input-group-addon">$</div>
                                <input type="text" class="form-control" id="amount-to-pay" placeholder="$0.00" value="236.25">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" type="button">Pay All</button>
                                </span>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Save changes</button>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->
    <!-- /Payment Update Modal Example -->
    <!-- /Modals -->
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <!--<script src="http://www2.gov.bc.ca/StaticWebResources/static/gov3/js/misc.js"></script>-->
    <!--<script src="js/misc.js"></script>-->
    <!--<script src="http://www2.gov.bc.ca/StaticWebResources/static/gov3/js/navMenu.js"></script>-->
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/ie10-viewport-bug-workaround.js"></script>


    <!-- DATATABLES SCRIPTS -->
    <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.10/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.10/js/dataTables.bootstrap.min.js"></script>

    <!-- Datatables config -->
    <script>
        $(function() {
            $('[data-toggle="tooltip"]').tooltip()
        })
    </script>
    <script type="text/javascript" charset="utf-8">
        $(document).ready(function() {
            $('#PBCSCN006-1').DataTable({
                "lengthMenu": [
                    [5, 10, 25, 50, -1],
                    [5, 10, 25, 50, "All"]
                ],
                "order": [
                    [1, "asc"]
                ],
                "aoColumns": [{
                    "bSortable": false
                }, {
                    "bSortable": true
                }, {
                    "bSortable": true
                }, {
                    "bSortable": true
                }, {
                    "bSortable": true
                }, {
                    "bSortable": true
                }, {
                    "bSortable": true
                }, {
                    "bSortable": true
                }, {
                    "bSortable": true
                }, {
                    "bSortable": true
                }, {
                    "bSortable": true
                }, {
                    "bSortable": false
                }, {
                    "bSortable": false
                }]
            });

        });
    </script>

    <script>
        $(function() {
            $('[data-toggle="tooltip"]').tooltip()
        })
    </script>
</body>

</html>