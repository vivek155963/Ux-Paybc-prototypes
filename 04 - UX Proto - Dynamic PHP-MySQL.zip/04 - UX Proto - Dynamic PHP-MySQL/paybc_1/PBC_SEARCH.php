

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1" .0>
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="apple-touch-icon" sizes="57x57" href="icons/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="icons/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="icons/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="icons/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="icons/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="icons/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="icons/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="icons/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192" href="icons/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="icons/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="icons/favicon-16x16.png">
    <link rel="manifest" href="icons/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="icons/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">

    <title>PayBC - Province of British Columbia</title>

    <!-- Bootstrap core CSS v3.3.6 -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link rel="stylesheet" href="css/ie10-viewport-bug-workaround.css" />

    <!-- Standard CSS -->
    <link type="text/css" href="http://www2.gov.bc.ca/StaticWebResources/static/gov3/css/main.css?refresh=160106102" rel="stylesheet" />

    <!-- Fonts -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

    <!-- Custom PayBC CSS -->
    <link href="css/paybc-main.css" rel="stylesheet" />
    <link href="css/paybc-form.css" rel="stylesheet" />
    <!-- DATATABLES CSS -->
    <link href="css/dataTables.bootstrap.min.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!-- Google ReCaptha -->
    <script src='https://www.google.com/recaptcha/api.js'></script>
    <style>
        .capatcha {
            text-align: center;
        }

        .g-recaptcha {
            display: inline-block;
        }

        .invoice-search {
            border: 1px solid #ccc;
            display: block;
            padding: 20px;
        }
    </style>
</head>

<body>
    <!-- Header -->
    <div id="header">
        <div id="header-main" class="navbar navbar-default navbar-fixed-top">
            <div class="container">
                <div id="header-main-row1" class="row">
                    <!-- GOV & PAYBC LOGOS -->
                    <div class="col-sm-5 header-main-left">
                        <div id="logo">
                            <a href="index.html">
                                <img src="http://www2.gov.bc.ca/StaticWebResources/static/gov3/images/homepage/gov3_bc_logo.png" alt="Government of B.C." title="Government of B.C." class="hidden-xs" />
                                <img src="img/gov-paybc-logo.png" data-at2x="img/gov-paybc-logo@2x.png" alt="Government of B.C." title="Government of B.C." class="visible-xs" style="max-width:133px;" />
                            </a>
                        </div>
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar">
                            <img src="http://www2.gov.bc.ca/StaticWebResources/static/gov3/images/mini-menu/menu-open-mobile.png" />
                        </button>
                        <a href="PBC_HOME.php" class="hidden-xs"><img src="img/PayBC-logo-sm.png" id="paybc-logo" alt="PayBC Logo" title="PayBC Logo"  class="hidden-xs" /></a>
                    </div><!-- /GOV & PAYBC LOGOS -->
                    <!-- PAYMENT LIST & LOGOUT BUTTONS -->
                    <div class="hidden-xs col-sm-7 header-main-right text-right">
                        <!--<label class="paybc-username"><i class="fa fa-lock"></i>&nbsp;IDIR\PSMITH</label>-->
                        <!--<a href="#" class="btn btn-default btn-sm paybc-pmt-list">Payment List <span class="paybe-pmt-list-total">($2,345.67)</span></a>-->
                        <a role="button" class="btn btn-sm btn-success paybc-authenticate" href="PBCSCN002.html">Sign In</a>
                        <!--<a href="PBCSCN001.html" class="btn btn-sm btn-warning paybc-authenticate">Sign Out</a>-->
                    </div><!-- PAYMENT LIST BUTTON -->
                    <!-- COLLAPSING NAVBAR -->
                    <div id="navbar" class="collapse navbar-collapse">
                        <div class="row visible-xs paybc-user">
                            <!--<div class="col-xs-4 col-xs-offset-8 text-center">
                                <label class="paybc-username"><i class="fa fa-lock"></i>&nbsp;IDIR\PSMITH</label>
                            </div>-->
                            <div class="col-xs-8">
                                <!--<a role="button" class="btn btn-default btn-block paybc-pmt-list">Payment List <span class="paybe-pmt-list-total">($2,345.67)</span></a>-->
                            </div>
                            <div class="col-xs-4">
                                <!--<a role="button" class="btn btn-warning btn-block paybc-authenticate">Sign Out</a>-->
                                <a role="button" class="btn btn-success btn-block paybc-authenticate" href="PBCSCN002.html">Sign In</a>
                            </div>
                        </div>
                        <ul class="nav navbar-nav">
                            <li><a href="PBC_HOME.php">PayBC Home</a></li>
                            <li><a href="PBC_SEARCH.php">PayBC Quick-Pay</a></li>
                            <li><a href="">FAQ</a></li>
                        </ul>
                    </div><!-- /COLLAPSING NAVBAR -->
                </div>
            </div>
            <div class="navigationRibbon">
                <div class="level2Navigation">
                    <div class="container">
                        <a href="PBC_HOME.php">PayBC Home</a>
                        <a href="PBC_SEARCH.php">PayBC Quick-Pay</a>
                        <a href="">FAQ</a>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- /Header -->
    <!-- BODY CONTENT -->
    <div id="subthemeTemplate" class="template container paybc-container">
        <div id="breadcrumbContainer">
            <ol class="breadcrumb">
                <li>
                    <a href="PBC_HOME.php">PayBC Home</a>
                </li>
                <li>
                    Quick-Pay
                </li>
            </ol>
        </div>
        <a id="main-content-anchor"></a>

        <div class="row">
            <div id="main-content" class="contentPageMainColumn col-xs-12">
                <h1>PayBC Quick-Pay</h1>
                <div id="pageIntro">

                </div>
                <div class="row">
                    <div class="col-md-9">
                        <div class="panel panel-paybc">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-search pull-left text-paybc" title="Search for a Single Payable Items"></i> Find my Invoice</h3>
                                <div class="clearfix"></div>
                            </div>
                            <div class="panel-body">
                                <form action="PBC_RESULTS.php" method="post">
                                    <div class="row">
                                    <div class="col-xs-12">
                                        <p><strong>Enter the <u><a href="" data-toggle="modal" data-target="#VT-Modal">Violation Ticket Number</a></u> from the top of your Violation Ticket.</strong> <em><a href="" data-toggle="modal" data-target="#VT-Modal">(see an example)</a></em></p>
                                        <p>Click here for more information about penalties, including points, prohibitions, impoundments, suspensions, and more.</p>
                                    </div>
                                </div>
                                <div class="row"><br />
                                    <input type="hidden" name="ref_no" class="form-control" value="10006">
                                    <div class="form-group col-xs-12 col-sm-4 col-sm-offset-2 col-md-4 col-md-offset-2">
                                        <label for="contribution-value">Violation Ticket Number</label>
                                        <input type="text" class="form-control" name="transaction_no" placeholder="AH12345678" value="AH" maxlength="10">
                                    </div>
                                    <div class="form-group col-xs-12 col-sm-4 col-md-4">
                                        <label class="hidden-xs">&nbsp;</label>
                                        <button id="" class="btn btn-primary form-control" type="submit">Find my Violation Ticket</a>
                                    </div>
                                </div>
                                <div class="row"><br />
                                    <div class="col-md-6 col-md-offset-3 text-center">
                                        <div class="g-recaptcha" data-sitekey="6LeWkAoUAAAAABlcRTOS5R9SdW--vY-X8dWbzXy1"></div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="panel panel-paybc">
                            <div class="panel-heading">
                                <h3 class="panel-title">Useful Contacts</h3>
                            </div>
                            <div class="panel-body">
                                <p>Please read the <strong><a href="">PayBC FAQs</a></strong> for answers to common questions.</p>
                                <p>For more information please contact the PayBC Support Team:</p>
                                <address>
                                    <strong>Telephone:</strong><br />
                                    <i class="fa fa-phone-square" title="Phone"></i> <a href="tel:18665555848">1 866 555 5848</a>
                                    <br /><br />
                                    <strong>Email:</strong><br />
                                    <i class="fa fa-envelope-square" title="Email"></i> <a href="mailto:PayBC.77000@gov.bc.ca">PayBC.77000@gov.bc.ca</a>
                                </address>
                                <p>
                                    <strong>PayBC Support hours:</strong><br />
                                    Monday-Friday, 8am-4pm
                                </p>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>
    <!-- /BODY CONTENT -->
    <!-- FOOTER -->
    <div id="footer">
        <div id="footerWrapper">
            <div id="footerAdminSection">
                <div id="footerAdminLinksContainer" class="container">
                    <div id="footerAdminLinks" class="row">
                        <ul class="inline">
                            <li>
                                <a href="#" target="_self">Home</a>
                            </li>
                            <li>
                                <a href="#" target="_self">About pay.gov.bc.ca</a>
                            </li>
                            <li>
                                <a href="#" target="_self">Disclaimer</a>
                            </li>
                            <li>
                                <a href="#" target="_self">Privacy</a>
                            </li>
                            <li>
                                <a href="#" target="_self">Accessibility</a>
                            </li>
                            <li>
                                <a href="#" target="_self">Copyright</a>
                            </li>
                            <li>
                                <a href="#" target="_self">Contact Us</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /FOOTER -->
    <!-- Modals -->
    <div class="modal fade" id="VT-Modal" tabindex="-1" role="dialog" aria-labelledby="BCoID-ModalLabel">
        <div class="modal-dialog modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="BCoID-ModalLabel">Violation Ticket Number</h4>
                </div>
                <div class="modal-body">
                    <p>The Violation Ticket Number is <strong>10 characters</strong> long, consisting of <strong>TWO letters</strong> followed by <strong>EIGHT numbers</strong> (e.g., AH123456789) and located at the top of your Traffic Violation Ticket.</p>
                    <img class="img-responsive center-block" src="img/_vt_thumbnail_wide.png" />
                </div>
                <div class="modal-footer">
                    <a class="btn btn-default btn-sm" data-dismiss="modal">Close</a>

                </div>

            </div>
        </div>
    </div><!-- /Modals -->
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <!--<script src="http://www2.gov.bc.ca/StaticWebResources/static/gov3/js/misc.js"></script>-->
    <!--<script src="js/misc.js"></script>-->
    <!--<script src="http://www2.gov.bc.ca/StaticWebResources/static/gov3/js/navMenu.js"></script>-->
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/ie10-viewport-bug-workaround.js"></script>

    <!-- Retina.js Image Plugin -->
    <script type="text/javascript" src="js/retina.js"></script>
</body>
</html>
